# ShopSmart: Your Digital Grocery Store Experience

## Overview
ShopSmart is a full-stack grocery web application that provides users with a seamless shopping experience. Users can browse products, manage their shopping cart, and authenticate themselves to make purchases.

## Client-Side
The client-side of the application is built using React. It includes the following components and pages:

- **Navbar**: A navigation component that displays links and user authentication status.
- **Home**: The landing page showcasing featured products and promotions.
- **Products**: A page that lists all available products for purchase.
- **Cart**: A page that allows users to view and manage their shopping cart.
- **Login**: A page for user authentication.

### Setup Instructions
1. **Clone the Repository**
   ```bash
   git clone <repository-url>
   cd ShopSmart/client
   ```

2. **Install Dependencies**
   ```bash
   npm install
   ```

3. **Run the Application**
   ```bash
   npm start
   ```

## Server-Side
The server-side of the application is built using Node.js and Express. It handles API requests for user authentication, product management, and order processing.

### Setup Instructions
1. **Navigate to the Server Directory**
   ```bash
   cd ShopSmart/server
   ```

2. **Install Dependencies**
   ```bash
   npm install
   ```

3. **Set Up Environment Variables**
   Create a `.env` file in the server directory and add your MongoDB connection string and any other necessary environment variables.

4. **Run the Server**
   ```bash
   npm start
   ```

## Features
- User authentication (registration and login)
- Product browsing and searching
- Shopping cart management
- Order processing

## Contributing
Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.

## License
This project is licensed under the MIT License.