import React from 'react';

export default function Users() {
  // Example users
  const users = [
    { id: '6614a859c30b51d3c700f1a0', name: 'syed', email: 'syed@gmail.com' }
  ];
  return (
    <div>
      <h2 className="page-title">Users</h2>
      <div className="table-box">
        <table>
          <thead>
            <tr>
              <th>sl/no</th>
              <th>UserId</th>
              <th>User name</th>
              <th>Email</th>
              <th>Operation</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u, idx) => (
              <tr key={u.id}>
                <td>{idx + 1}</td>
                <td>{u.id}</td>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td>
                  <button className="btn-delete">🗑</button>
                  <button className="btn-view">view</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}