import React from 'react';
import { Link } from 'react-router-dom';
import veggiesBg from '../images/veggies-bg.jpg';

export default function Home() {
  return (
    <div className="home-bg" style={{ backgroundImage: `url(${veggiesBg})` }}>
      <div>
        <h1 className="home-title">Welcome to Our Grocery Web App</h1>
        <p className="home-desc">
          Discover a wide range of Grocery's and Fresh Items for all your needs
        </p>
        <Link to="/products">
          <button className="home-btn">Shop Now</button>
        </Link>
      </div>
    </div>
  );
}