import React from 'react';
import appleImg from '../images/apple.jpg';
import milkImg from '../images/milk.jpg';
import chickenImg from '../images/chicken.jpg';

export default function Cart() {
  const cartItems = [
    { name: 'Apple', price: 200, image: appleImg },
    { name: 'Milk', price: 80, image: milkImg },
    { name: 'Chicken', price: 250, image: chickenImg }
  ];
  return (
    <div className="container">
      <h2 className="page-title">My Cart</h2>
      <div className="card-list">
        {cartItems.map((item, idx) => (
          <div className="card" key={idx}>
            <img src={item.image} alt={item.name} />
            <div className="product-title">{item.name}</div>
            <div className="product-price">${item.price}</div>
            <button className="btn btn-remove">Remove from Cart</button>
            <button className="btn btn-buy">Buy this</button>
          </div>
        ))}
      </div>
    </div>
  );
}