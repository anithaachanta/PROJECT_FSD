import React, { useState } from 'react';
import '../App.css';

export default function AddProduct() {
  const [form, setForm] = useState({
    name: '', rating: '', price: '', image: '', category: '', stock: '', description: ''
  });
  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });
  const handleSubmit = e => {
    e.preventDefault();
    // Add product logic here
    alert('Product added!');
  };
  return (
    <div>
      <h1 className="page-title">Add Product</h1>
      <form className="form-box" onSubmit={handleSubmit}>
        <div style={{ display: 'flex', gap: '16px' }}>
          <div style={{ flex: 1 }}>
            <label>Product Name</label>
            <input name="name" value={form.name} onChange={handleChange} placeholder="Enter product name" />
          </div>
          <div style={{ flex: 1 }}>
            <label>Rating</label>
            <input name="rating" value={form.rating} onChange={handleChange} placeholder="Enter product rating" />
          </div>
          <div style={{ flex: 1 }}>
            <label>Price</label>
            <input name="price" value={form.price} onChange={handleChange} placeholder="Enter product price" />
          </div>
        </div>
        <div style={{ display: 'flex', gap: '16px' }}>
          <div style={{ flex: 1 }}>
            <label>Image URL</label>
            <input name="image" value={form.image} onChange={handleChange} placeholder="Enter image URL" />
          </div>
          <div style={{ flex: 1 }}>
            <label>Category</label>
            <select name="category" value={form.category} onChange={handleChange}>
              <option value="">Select Category</option>
              <option value="fruits">Fruits</option>
              <option value="dairy">Dairy</option>
              <option value="meat">Meat</option>
            </select>
          </div>
          <div style={{ flex: 1 }}>
            <label>Count in Stock</label>
            <input name="stock" value={form.stock} onChange={handleChange} placeholder="Enter count in stock" />
          </div>
        </div>
        <label>Description</label>
        <textarea name="description" value={form.description} onChange={handleChange} placeholder="Enter product description" />
        <button className="btn-submit" type="submit">Add Product</button>
      </form>
    </div>
  );
}