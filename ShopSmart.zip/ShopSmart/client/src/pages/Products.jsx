import React from 'react';
import appleImg from '../images/apple.jpg';
import milkImg from '../images/milk.jpg';
import chickenImg from '../images/chicken.jpg';
import orangeImg from '../images/orange.jpg';
import cashewImg from '../images/cashew.jpg';

const products = [
  { name: 'Apple', price: 200, image: appleImg },
  { name: 'Orange', price: 120, image: orangeImg },
  { name: 'Milk', price: 80, image: milkImg },
  { name: 'Cashew', price: 800, image: cashewImg },
  { name: 'Chicken', price: 250, image: chickenImg }
];

export default function Products() {
  return (
    <div className="container">
      <h2 className="page-title">Products</h2>
      <div className="card-list">
        {products.map((p, idx) => (
          <div className="card" key={idx}>
            <img src={p.image} alt={p.name} />
            <div className="product-title">{p.name}</div>
            <div className="product-price">${p.price}</div>
            <button className="btn btn-buy">Buy Now</button>
            <button className="btn btn-cart">Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
}