import React from 'react';

export default function Orders() {
  const orders = [
    {
      id: '6614a8ddc30b51d3c700f1b4',
      name: 'syed arshad',
      phone: '9505221870',
      productId: '660e84641c659d0b2b10e135',
      quantity: 2,
      price: 400,
      payment: 'debit',
      address: 'hyderabad',
      date: '2024-04-09T02:36:47.498Z',
      status: 'Delivered'
    },
    {
      id: '6614b085c30b51d3c700f20a',
      name: 'syed arshad',
      phone: '9505221870',
      productId: '660e84641c659d0b2b10e135',
      quantity: 2,
      price: 400,
      payment: 'credit',
      address: 'hyderabad',
      date: '2024-04-09T03:05:41.563Z',
      status: 'Pending'
    }
  ];
  return (
    <div>
      <h1 className="page-title">Orders</h1>
      {orders.map(order => (
        <div className="order-details" key={order.id}>
          <div><strong>Order ID:</strong> {order.id}</div>
          <div><strong>Fullname:</strong> {order.name}</div>
          <div><strong>Phone:</strong> {order.phone}</div>
          <div><strong>Product ID:</strong> {order.productId}</div>
          <div><strong>Quantity:</strong> {order.quantity}</div>
          <div><strong>Total price:</strong> {order.price}</div>
          <div><strong>Payment Method:</strong> {order.payment}</div>
          <div><strong>Address:</strong> {order.address}</div>
          <div><strong>Created At:</strong> {order.date}</div>
          <div><strong>Status:</strong> {order.status}
            {order.status === 'Delivered' && (
              <span style={{
                marginLeft: '16px',
                background: '#ccc',
                color: '#fff',
                padding: '6px 24px',
                borderRadius: '6px'
              }}>Delivered</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}