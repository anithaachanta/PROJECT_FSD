import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="navbar">
      <span className="logo">Grocery Web App</span>
      <div className="nav-links">
        <Link to="/">Dashboard</Link>
        <Link to="/users">Users</Link>
        <Link to="/products">Products</Link>
        <Link to="/add-product">Add product</Link>
        <Link to="/orders">Orders</Link>
        <Link to="/login">Logout</Link>
      </div>
    </nav>
  );
}