# ShopSmart: Your Digital Grocery Store Experience

Welcome to ShopSmart, your go-to digital grocery store! This application allows users to browse products, manage their shopping cart, and authenticate their accounts seamlessly. Below you will find setup instructions, features, and usage guidelines for both the client and server sides of the application.

## Features

- **User Authentication**: Users can register and log in to manage their accounts.
- **Product Browsing**: Users can view a list of available products and their details.
- **Shopping Cart Management**: Users can add, update, and remove items from their shopping cart.
- **Responsive Design**: The application is designed to work on various devices.

## Project Structure

The project is divided into two main parts: the client and the server.

### Client

The client-side is built with React and includes the following components and pages:

- **Navbar**: Handles navigation links and user authentication status.
- **Home**: Displays featured products and promotional content.
- **Products**: Lists all available products for purchase.
- **Cart**: Manages the shopping cart functionality.
- **Login**: Provides the login interface for user authentication.

### Server

The server-side is built with Node.js and Express, and it includes:

- **Models**: Defines the schemas for User, Product, and Order.
- **Routes**: Handles API requests for authentication, products, and orders.
- **Controllers**: Contains the logic for processing requests and interacting with the database.

## Setup Instructions

### Client Setup

1. Navigate to the `client` directory.
2. Install dependencies:
   ```
   npm install
   ```
3. Start the development server:
   ```
   npm start
   ```

### Server Setup

1. Navigate to the `server` directory.
2. Create a `.env` file and add your MongoDB connection string:
   ```
   MONGO_URI=your_mongodb_connection_string
   PORT=5100
   ```
3. Install dependencies:
   ```
   npm install
   ```
4. Start the server:
   ```
   npm start
   ```

## Usage Guidelines

- Access the client application in your browser at `http://localhost:3000`.
- Use the provided login interface to authenticate or create a new account.
- Browse products and manage your shopping cart as needed.

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue for any enhancements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.