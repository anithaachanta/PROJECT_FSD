const config = {
    mongoURI: process.env.MONGO_URI || 'mongodb://localhost:27017/shopsmart',
    jwtSecret: process.env.JWT_SECRET || 'your_jwt_secret',
    port: process.env.PORT || 5100,
};

module.exports = config;