# ShopSmart: Your Digital Grocery Store Experience

## Overview
ShopSmart is a full-stack grocery web application designed to provide users with a seamless online shopping experience. The application allows users to browse products, manage their shopping cart, and authenticate their accounts for a personalized experience.

## Project Structure
The project is divided into two main parts: the client-side and the server-side.

### Client
The client-side is built using React and contains the following components and pages:
- **Navbar**: Handles navigation links and user authentication status.
- **Home**: Displays featured products and promotional content.
- **Products**: Lists all available products for purchase.
- **Cart**: Manages the shopping cart functionality.
- **Login**: Provides a login interface for user authentication.

### Server
The server-side is built using Node.js and Express, and it includes:
- **Models**: Defines the schemas for User, Product, and Order.
- **Routes**: Handles API requests for authentication, products, and orders.
- **Controllers**: Contains the logic for processing requests related to authentication, products, and orders.

## Setup Instructions

### Prerequisites
- Node.js and npm installed on your machine.
- MongoDB database set up and accessible.

### Client Setup
1. Navigate to the `client` directory:
   ```
   cd client
   ```
2. Install the dependencies:
   ```
   npm install
   ```
3. Start the client application:
   ```
   npm start
   ```

### Server Setup
1. Navigate to the `server` directory:
   ```
   cd server
   ```
2. Create a `.env` file in the `server` directory and add your MongoDB connection string:
   ```
   MONGO_URI=your_mongodb_connection_string
   PORT=5100
   ```
3. Install the dependencies:
   ```
   npm install
   ```
4. Start the server application:
   ```
   npm start
   ```

## Features
- User authentication with registration and login functionality.
- Product browsing with detailed views.
- Shopping cart management for adding, updating, and removing items.
- Order management for tracking purchases.

## Usage Guidelines
- Access the client application through your web browser at `http://localhost:3000`.
- Use the server API for data operations, which runs on `http://localhost:5100/api`.

## Contributing
Contributions are welcome! Please feel free to submit a pull request or open an issue for any enhancements or bug fixes.

## License
This project is licensed under the MIT License.